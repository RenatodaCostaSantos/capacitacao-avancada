# ==========================================
# TELECOM ANOMALY — CORE PIPELINE
# Treino + Feature Engineering + Persistência
# ==========================================

import pandas as pd
import numpy as np
import joblib
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.metrics import (
    accuracy_score, precision_score,
    recall_score, f1_score,
    classification_report, confusion_matrix
)

from sklearn.metrics import f1_score, recall_score, precision_score
import numpy as np
import matplotlib.pyplot as plt

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

MODELS_DIR = Path("models")
MODELS_DIR.mkdir(exist_ok=True)

# ==========================================
# CONFIG
# ==========================================

@dataclass
class PipelineConfig:
    contamination: float = 0.5
    n_estimators: int = 600
    random_state: int = 42
    threshold_percentile: float = 50.0          # percentil sobre scores normais
    model_path: str = "models/isolation_forest.joblib"
    scaler_path: str = "models/scaler.joblib"
    threshold_path: str = "models/threshold.joblib"

# ==========================================
# STEP 1 — LOAD CSV FILES
# ==========================================

def load_files(files: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Carrega os CSV de normal e failure, adiciona metadados.
    files = {"normal": [...paths], "failure": [...paths]}
    """
    def _load_group(paths, label):
        dfs = []
        for i, path in enumerate(paths):
            try:
                df = pd.read_csv(path)
                df["label"]          = label
                df["measurement_id"] = f"measurement_{i}"
                df["time_ns"]        = pd.to_numeric(df["%time"], errors="coerce")
                df["time_s"]         = df["time_ns"] / 1e9
                df["time_rel_s"]     = df["time_s"] - df["time_s"].min()
                df = df.sort_values("time_ns").reset_index(drop=True)
                dfs.append(df)
                log.info(f"  Loaded: {path}  ({len(df)} rows, label={label})")
            except Exception as e:
                log.warning(f"  Skipped {path}: {e}")
        return pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()

    df_normal  = _load_group(files["normal"],  label=0)
    df_failure = _load_group(files["failure"], label=1)
    log.info(f"Normal: {df_normal.shape}  |  Failure: {df_failure.shape}")
    return df_normal, df_failure


# ==========================================
# STEP 2 — CLEAN
# ==========================================

EXTRA_COLS = ["time_s", "time_rel_s", "measurement_id", "label"]

def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    value_cols = [c for c in df.columns if "value" in c]
    keep       = value_cols + [c for c in EXTRA_COLS if c in df.columns]

    df_clean = df[keep].copy()
    df_clean[value_cols] = df_clean[value_cols].apply(pd.to_numeric, errors="coerce")
    df_clean[value_cols] = df_clean[value_cols].ffill().bfill().fillna(0)
    return df_clean


# ==========================================
# STEP 3 — FEATURE ENGINEERING
# ==========================================

TELECOM_COLS = [
    "time_s", "time_rel_s", "label",
    "received_packets", "dropped_packets",
    "rx_total_bytes",   "tx_total_bytes",
    "rx_speed",         "tx_speed",
    "throughput",       "packet_rate",
    "packet_loss_rate", "byte_rate",
    "jitter",           "buffer_overruns",
    "parse_errors",
]

FEATURE_COLS = [   # colunas usadas pelo modelo (sem metadados)
    "received_packets", "dropped_packets",
    "rx_total_bytes",   "tx_total_bytes",
    "rx_speed",         "tx_speed",
    "throughput",       "packet_rate",
    "packet_loss_rate", "byte_rate",
    "jitter",           "buffer_overruns",
    "parse_errors",
]


def create_telecom_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    df["time_s"]         = pd.to_numeric(df.get("time_s"), errors="coerce")
    df["time_rel_s"]     = pd.to_numeric(df.get("time_rel_s"), errors="coerce")
    df["label"]          = pd.to_numeric(df.get("label"), errors="coerce")

    # raw metrics
    df["rx_speed"]          = pd.to_numeric(df.get("field.status0.values6.value"), errors="coerce")
    df["tx_speed"]          = pd.to_numeric(df.get("field.status0.values7.value"), errors="coerce")
    df["rx_total_bytes"]    = pd.to_numeric(df.get("field.status0.values4.value"), errors="coerce")
    df["tx_total_bytes"]    = pd.to_numeric(df.get("field.status0.values5.value"), errors="coerce")
    df["received_packets"]  = pd.to_numeric(df.get("field.status0.values0.value"), errors="coerce")
    df["dropped_packets"]   = pd.to_numeric(df.get("field.status0.values1.value"), errors="coerce")
    df["buffer_overruns"]   = pd.to_numeric(df.get("field.status0.values2.value"), errors="coerce")
    df["parse_errors"]      = pd.to_numeric(df.get("field.status0.values3.value"), errors="coerce")

    # engineered features
    df["throughput"]        = df["rx_speed"] + df["tx_speed"]
    df["packet_rate"]       = df["received_packets"].diff().clip(lower=0)
    df["packet_loss_rate"]  = df["dropped_packets"].diff().clip(lower=0)
    df["byte_rate"]         = df["rx_total_bytes"].diff().clip(lower=0)
    df["jitter"]            = df["rx_speed"].diff().abs().rolling(5).mean()

    df = df.ffill().bfill().fillna(0)

    # remover colunas zeradas
    available = [c for c in TELECOM_COLS if c in df.columns]
    df_out = df[available].copy()

    zero_cols = [c for c in FEATURE_COLS
                 if c in df_out.columns
                 and df_out[c].min() == 0 and df_out[c].max() == 0]
    if zero_cols:
        log.info(f"  Removing zero columns: {zero_cols}")
        df_out.drop(columns=zero_cols, inplace=True, errors="ignore")

    return df_out


# ==========================================
# STEP 4 — TRAIN
# ==========================================

@dataclass
class TrainResult:
    model: IsolationForest
    scaler: StandardScaler
    threshold: float
    feature_cols: list[str]
    metrics: dict = field(default_factory=dict)


def train(
    df_normal: pd.DataFrame,
    df_failure: pd.DataFrame,
    config: PipelineConfig = PipelineConfig()
) -> TrainResult:

    feat_cols = [c for c in FEATURE_COLS if c in df_normal.columns]
    log.info(f"Features usadas ({len(feat_cols)}): {feat_cols}")

    # normalizar
    scaler  = StandardScaler()
    X_train = scaler.fit_transform(df_normal[feat_cols])

    X_normal  = scaler.transform(df_normal[feat_cols])
    X_failure = scaler.transform(df_failure[feat_cols])
    X_test    = np.vstack([X_normal, X_failure])
    y_test    = np.concatenate([
        np.zeros(len(X_normal)),
        np.ones(len(X_failure))
    ])

    # treinar APENAS com dados normais
    log.info("Treinando IsolationForest (apenas dados normais)...")
    model = IsolationForest(
        n_estimators=config.n_estimators,
        contamination=config.contamination,
        random_state=config.random_state
    )
    model.fit(X_train)

    # threshold calibrado sobre o conjunto de validação normal
    scores_normal = model.decision_function(X_normal)
    threshold     = np.percentile(scores_normal, config.threshold_percentile)
    log.info(f"Threshold calibrado: {threshold:.4f} (percentil {config.threshold_percentile})")

    # avaliação
    scores_test = model.decision_function(X_test)
    y_pred      = (scores_test < threshold).astype(int)

    metrics = {
        "accuracy":  round(float(accuracy_score(y_test, y_pred)),  4),
        "precision": round(float(precision_score(y_test, y_pred)), 4),
        "recall":    round(float(recall_score(y_test, y_pred)),    4),
        "f1":        round(float(f1_score(y_test, y_pred)),        4),
        "threshold": round(float(threshold), 6),
        "n_features": len(feat_cols),
        "n_train_samples": len(X_train),
        "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
    }

    log.info("===== RESULTADOS =====")
    for k, v in metrics.items():
        if k != "confusion_matrix":
            log.info(f"  {k}: {v}")
    log.info("\n" + classification_report(y_test, y_pred))

    # salvar
    joblib.dump(model,     config.model_path)
    joblib.dump(scaler,    config.scaler_path)
    joblib.dump({
        "threshold": threshold,
        "feature_cols": feat_cols,
        "metrics": metrics
    }, config.threshold_path)
    log.info(f"Modelo salvo em: {config.model_path}")
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    # 
    # 
    # 
    '''scores_normal  = model.decision_function(X_normal)
    scores_failure = model.decision_function(X_failure)
    scores_all     = np.concatenate([scores_normal, scores_failure])
    y_true         = np.concatenate([np.zeros(len(scores_normal)), np.ones(len(scores_failure))])

    results = []
    for pct in np.arange(1, 80, 1):
        thr    = np.percentile(scores_normal, pct)
        y_pred = (scores_all < thr).astype(int)
        results.append({
            "pct":       pct,
            "threshold": thr,
            "f1":        f1_score(y_true, y_pred),
            "recall":    recall_score(y_true, y_pred),
            "precision": precision_score(y_true, y_pred),
            "f1_normal": f1_score(y_true, y_pred, pos_label=0),
        })

    df_r = pd.DataFrame(results)

    # melhor F1 geral
    best_f1  = df_r.loc[df_r["f1"].idxmax()]

    # melhor F1 macro (equilibra as duas classes)
    df_r["f1_macro"] = (df_r["f1"] + df_r["f1_normal"]) / 2
    best_macro = df_r.loc[df_r["f1_macro"].idxmax()]

    print(f"Melhor F1 failure  → pct={best_f1['pct']:.0f}%  threshold={best_f1['threshold']:.4f}  F1={best_f1['f1']:.4f}  recall={best_f1['recall']:.4f}")
    print(f"Melhor F1 macro    → pct={best_macro['pct']:.0f}%  threshold={best_macro['threshold']:.4f}  F1_macro={best_macro['f1_macro']:.4f}")

    plt.figure(figsize=(12, 4))
    plt.plot(df_r["pct"], df_r["f1"],        label="F1 failure",  linewidth=2, color="tomato")
    plt.plot(df_r["pct"], df_r["f1_normal"], label="F1 normal",   linewidth=2, color="steelblue")
    plt.plot(df_r["pct"], df_r["f1_macro"],  label="F1 macro",    linewidth=2, color="purple", linestyle="--")
    plt.plot(df_r["pct"], df_r["recall"],    label="Recall",      linewidth=1, color="tomato",    linestyle=":")
    plt.plot(df_r["pct"], df_r["precision"], label="Precision",   linewidth=1, color="green",     linestyle=":")
    plt.axvline(best_macro["pct"], color="black", linestyle="--", alpha=0.5, label=f"Melhor macro pct={best_macro['pct']:.0f}%")
    plt.axvline(50, color="gray", linestyle=":", alpha=0.4, label="Atual pct=50%")
    plt.xlabel("Percentil do threshold")
    plt.ylabel("Score")
    plt.title("Trade-off: onde o threshold equilibra melhor as duas classes")
    plt.legend()
    plt.tight_layout()
    plt.show()'''                       
    return TrainResult(
        model=model,
        scaler=scaler,
        threshold=threshold,
        feature_cols=feat_cols,
        metrics=metrics
    )


# ==========================================
# STEP 5 — LOAD MODEL (produção)
# ==========================================

def load_model(config: PipelineConfig = PipelineConfig()) -> TrainResult:
    model  = joblib.load(config.model_path)
    scaler = joblib.load(config.scaler_path)
    meta   = joblib.load(config.threshold_path)
    log.info(f"Modelo carregado | features: {meta['feature_cols']} | threshold: {meta['threshold']:.4f}")
    return TrainResult(
        model=model, scaler=scaler,
        threshold=meta["threshold"],
        feature_cols=meta["feature_cols"],
        metrics=meta.get("metrics", {})
    )


# ==========================================
# STEP 6 — PREDICT (single sample, em tempo real)
# ==========================================

@dataclass
class PredictionResult:
    score: float
    is_anomaly: bool
    anomaly_level: str       # "normal" | "warning" | "critical"
    confidence: float        # 0-1
    features: dict


def predict(
    sample: dict,
    result: TrainResult
) -> PredictionResult:
    """
    sample: dicionário com os valores das features brutas (1 amostra)
    result: TrainResult carregado do disco ou vindo do treino
    """
    row = pd.DataFrame([sample])

    # garantir que todas as features existam
    for col in result.feature_cols:
        if col not in row.columns:
            row[col] = 0.0

    X = result.scaler.transform(row[result.feature_cols])
    score = float(result.model.decision_function(X)[0])

    is_anomaly = score < result.threshold
    margin     = result.threshold - score       # positivo = mais anômalo

    if not is_anomaly:
        level      = "normal"
        confidence = min(1.0, abs(score - result.threshold) / max(abs(result.threshold), 0.01))
    elif margin < 0.15:
        level      = "warning"
        confidence = 0.5 + margin * 2
    else:
        level      = "critical"
        confidence = min(1.0, 0.7 + margin)

    return PredictionResult(
        score=round(score, 6),
        is_anomaly=is_anomaly,
        anomaly_level=level,
        confidence=round(confidence, 4),
        features={k: round(float(sample.get(k, 0)), 4) for k in result.feature_cols}
    )
